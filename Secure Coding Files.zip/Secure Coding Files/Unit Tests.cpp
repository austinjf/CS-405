// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
//    FAIL();
//}

// Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // verify collection is empty
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    // verify collection has one entry
    ASSERT_EQ(collection->size(), 1);
}

// Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // verify collection is empty
    EXPECT_EQ(collection->size(), 0);

    add_entries(5);

    // verify collection has five entries
    ASSERT_EQ(collection->size(), 5);
}

// Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeIsGEQToMultipleEntries)
{
    // verify collection is empty and max_size is GEQ
    EXPECT_EQ(collection->size(), 0);
    ASSERT_GE(collection->max_size(), collection->size());

    // add entry, verify max_size is GEQ
    add_entries(1);
    ASSERT_GE(collection->max_size(), collection->size());

    // add entries to make 5 entries, verify max_size is GEQ
    add_entries(4);
    ASSERT_GE(collection->max_size(), collection->size());

    // add entries to make 10 entries, verify max_size is GEQ
    add_entries(5);
    ASSERT_GE(collection->max_size(), collection->size());
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityIsGEQToMultipleEntries)
{
    // verify collection is empty and max_size is GEQ
    EXPECT_EQ(collection->size(), 0);
    ASSERT_GE(collection->capacity(), collection->size());

    // add entry, verify max_size is GEQ
    add_entries(1);
    ASSERT_GE(collection->capacity(), collection->size());

    // add entries to make 5 entries, verify max_size is GEQ
    add_entries(4);
    ASSERT_GE(collection->capacity(), collection->size());

    // add entries to make 10 entries, verify max_size is GEQ
    add_entries(5);
    ASSERT_GE(collection->capacity(), collection->size());
}

// Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizingIncreasesCollection)
{
    // declare newSize var for later comparison
    unsigned int newSize = collection->size() + 1;

    collection->resize(newSize);

    // verify size of collection is newSize
    ASSERT_EQ(collection->size(), newSize);
}

// Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizingDecreasesCollection)
{
    // set size of collection to 2
    collection->resize(2);
    
    // declare newSize var for later comparison
    unsigned int newSize = collection->size() - 1;

    collection->resize(newSize);

    // verify size of collection is newSize
    ASSERT_EQ(collection->size(), newSize);
}

// Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizingDecreasesCollectionToZero)
{
    // add some entries
    add_entries(5);
    
    // set size of collection to 0
    collection->resize(0);

    ASSERT_EQ(collection->size(), 0);
    ASSERT_TRUE(collection->empty());
}

// Create a test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    // add some entries
    add_entries(5);

    // clear collection
    collection->clear();

    ASSERT_EQ(collection->size(), 0);
    ASSERT_TRUE(collection->empty());
}

// Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseWithParamsErasesCollection)
{
    // add some entries
    add_entries(5);

    // erase collection
    collection->erase(collection->begin(), collection->end());

    ASSERT_EQ(collection->size(), 0);
    ASSERT_TRUE(collection->empty());
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityButNotSize)
{
    EXPECT_EQ(collection->size(), 0);

    unsigned int oldCapacity = collection->capacity();

    // reserve some capacity
    collection->reserve(100);
    unsigned int newCapacity = collection->capacity();

    // verify newCapacity > oldCapacity
    ASSERT_GT(newCapacity, oldCapacity);
    // verify collection size is still 0
    ASSERT_EQ(collection->size(), 0);
}

// Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, WillThrowOutOfRangeException)
{
    EXPECT_EQ(collection->size(), 0);

    // add some entries
    add_entries(2);

    // verify exception thrown when calling at() with out of bound index
    ASSERT_THROW(collection->at(2), std::out_of_range);
}

// Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative

// Create a (positive) test to verify that all values in the collection (n) are: 0 <= n < 100
TEST_F(CollectionTest, CollectionValuesBetween0And100)
{
    EXPECT_EQ(collection->size(), 0);

    // add a random number of entries between 1 and 100
    add_entries((rand() % 100) + 1);

    unsigned int size = collection->size();

    for (auto i = 0; i < size; ++i) {
        ASSERT_GE(collection->at(i), 0);
        ASSERT_LT(collection->at(i), 100);
    }
}

// Create a (negative) test to verify the std::length_error is thrown when the collection vector is resized larger than max_size
TEST_F(CollectionTest, WillThrowLengthErrorException)
{
    ASSERT_THROW(collection->resize(collection->max_size() + 1), std::length_error);
}